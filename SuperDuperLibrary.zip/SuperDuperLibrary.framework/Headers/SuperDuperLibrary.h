//
//  SuperDuperLibrary.h
//  SuperDuperLibrary
//
//  Created by Roberto Carrera on 1/17/19.
//  Copyright © 2019 MuukTechnologies. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SuperDuperLibrary.
FOUNDATION_EXPORT double SuperDuperLibraryVersionNumber;

//! Project version string for SuperDuperLibrary.
FOUNDATION_EXPORT const unsigned char SuperDuperLibraryVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SuperDuperLibrary/PublicHeader.h>


